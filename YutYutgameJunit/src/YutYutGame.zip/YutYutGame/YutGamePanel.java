package YutYutGame;

import javax.swing.*;
import java.awt.*;

public class YutGamePanel extends JPanel {

    private final DefaultListModel<String> resultModel = new DefaultListModel<>();
    private final JList<String> resultList = new JList<>(resultModel);
    private final JLabel resultLabel = new JLabel("결과: ");
    private final Yut yut = new Yut();

    private boolean rerollYut = true;
    private Runnable onThrowFinished;
    private final Rule yutRule;

    public YutGamePanel(Rule yutRule) {
        this.yutRule = yutRule;
        setLayout(new GridLayout(1, 2));
        add(createYutPanel());
        add(createResultPanel());
    }

    public void setOnThrowFinished(Runnable callback) {
        this.onThrowFinished = callback;
    }

    private void triggerCallbackIfSet() {
        if (onThrowFinished != null) {
            onThrowFinished.run();
        }
    }

    private JPanel createYutPanel() {
        JPanel yutPanel = new JPanel();
        yutPanel.setLayout(new BoxLayout(yutPanel, BoxLayout.Y_AXIS));
        yutPanel.setBorder(BorderFactory.createTitledBorder("윷 던지기"));

        resultLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        resultLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));

        JButton fixButton = new JButton("결과 선택");
        JButton randButton = new JButton("무작위 던지기");

        fixButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        randButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        fixButton.addActionListener(e -> {
            String selected = (String) JOptionPane.showInputDialog(
                    this, "결과를 선택하세요:", "윷 결과 선택",
                    JOptionPane.PLAIN_MESSAGE, null,
                    yut.getOutcomes(), yut.getOutcomes()[0]
            );
            if (selected != null) {
                updateResult(selected);
                yut.setSelectedResult(yut.getIdxOutcomes(selected));
            }
        });

        randButton.addActionListener(e -> {
            if (rerollYut) {
                int idx = yut.throwYutRand();
                String selected = yut.getOutcomes()[idx];
                updateResult(selected);

                if (idx > 3) {
                    rerollYut = true; // 윷 or 모 → 다시 던짐
                } else {
                    rerollYut = false;
                }
            }
        });

        yutPanel.add(Box.createVerticalStrut(30));
        yutPanel.add(resultLabel);
        yutPanel.add(Box.createVerticalStrut(20));
        yutPanel.add(fixButton);
        yutPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        yutPanel.add(randButton);

        return yutPanel;
    }

    private JPanel createResultPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("저장된 결과"));

        resultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(resultList);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton useButton = new JButton("선택한 결과 사용");

        useButton.addActionListener(e -> {
            String selected = resultList.getSelectedValue();
            if (selected != null) {
                int idx = yut.getIdxOutcomes(selected);
                yutRule.setDistance(idx);
                resultModel.removeElement(selected);
                yut.useResult(idx);

                JOptionPane.showMessageDialog(this, "사용한 결과: " + selected);

                if (yut.isAllUsed()) {
                    yutRule.markYutUsedUp();
                    rerollYut = true;
                    JOptionPane.showMessageDialog(this, "모든 윷 결과를 사용했습니다.");
                }

                triggerCallbackIfSet();
            } else {
                JOptionPane.showMessageDialog(this, "결과를 선택해주세요.");
            }
        });

        panel.add(useButton, BorderLayout.SOUTH);
        return panel;
    }

    private void updateResult(String selected) {
        resultLabel.setText("결과: " + selected);
        resultModel.addElement(selected);
    }

    public void incrementRerollCount() {
        rerollYut = true;
    }
}
//바뀜