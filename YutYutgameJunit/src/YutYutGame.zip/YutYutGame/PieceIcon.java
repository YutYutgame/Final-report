package YutYutGame;

import javax.swing.*;
import java.awt.*;


class PieceIcon extends JPanel {
    private final Color color;

    public PieceIcon(Color color) {
        this.color = color;
        setPreferredSize(new Dimension(24, 24));
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.LIGHT_GRAY);
        g.fillOval(2, 2, getWidth() - 4, getHeight() - 4);
        g.setColor(Color.DARK_GRAY);
        g.drawOval(2, 2, getWidth() - 4, getHeight() - 4);
    }
}

