package YutYutGame;

public class Rule {

    private int distance = 0;              // 현재 이동 거리
    private int currentPlayerIndex = 0;    // 현재 턴 플레이어 인덱스
    private final int playerCount;         // 총 플레이어 수

    private boolean yutIsEmpty = false;    // 윷 결과 모두 소진 여부
    private boolean pieceMoved = false;    // 이번 턴에 실제 말 이동 여부

    public Rule(int playerCount) {
        this.playerCount = playerCount;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getDistance() {
        return distance;
    }

    public int getCurrentPlayerIndex() {
        return currentPlayerIndex;
    }

    public void markYutUsedUp() {
        this.yutIsEmpty = true;
    }

    public void markPieceMoved(boolean moved) {
        this.pieceMoved = moved;
    }

    public void changePlayerIfTurnDone() {
        if (yutIsEmpty && pieceMoved) {
            currentPlayerIndex = (currentPlayerIndex + 1) % playerCount;
            yutIsEmpty = false;
            pieceMoved = false;
        }
    }

    public void forceNextTurn() {
        currentPlayerIndex = (currentPlayerIndex + 1) % playerCount;
        yutIsEmpty = false;
        pieceMoved = false;
    }

    public boolean isYutUsedUp() {
        return yutIsEmpty;
    }

    public boolean hasPieceMoved() {
        return pieceMoved;
    }
}
//바뀜